import java.io.*;
import java.io.FileReader;
import java.util.ArrayList;
import java.text.DecimalFormat;
import java.io.FileWriter;
import java.io.IOException;
import java.io.FileNotFoundException; 
import java.util.LinkedHashMap; 
import java.util.Map;  
import org.json.simple.JSONObject; 
public class Hackathon {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String text = "";
		

		ArrayList<Integer> values=new ArrayList<Integer>();
		ArrayList<Double> mb=new ArrayList<Double>();

		try {
			FileReader readfile = new FileReader("E:\\java\\Memory.txt");
			BufferedReader readbuffer = new BufferedReader(readfile);
			
			int j=0;
			while(readbuffer.readLine()!=null)
			{
				if (j % 2 == 0) {
					text = readbuffer.readLine() + "\n";
					text = text.replaceAll("( )+", " ");

					String[] str=text.split(" ");
					String value=str[2].toString();
					values.add(Integer.parseInt(value));

				} else
					readbuffer.readLine();

				j++;
			}
			
			readbuffer.close();
		}
		catch(FileNotFoundException e){e.printStackTrace();}
		catch(IOException e){e.printStackTrace();}
		

		double avg=0.00;
		double max=0.00;
		
		DecimalFormat df = new DecimalFormat("#0.00");      
		

		for(int i=0;i<values.size();i++)
		{
			double mbValue=(double)values.get(i)/1024;
			mbValue = Double.valueOf(df.format(mbValue));

			avg=avg+mbValue;
			if(mbValue>max)
			{
				max=mbValue;
			}

			mb.add(mbValue);
		}
		max = Double.valueOf(df.format(max));
		
		JSONObject obj = new JSONObject();
		avg=avg/mb.size();
		avg = Double.valueOf(df.format(avg));
		obj.put("AverageMemory(MB)", avg);
		
		Map m = new LinkedHashMap(mb.size()); 
	       
		for(int i=0;i<mb.size();i++)
		{	
			 m.put((i+1)+"s", mb.get(i)); 
		}
		obj.put("values", m);

		obj.put("MaxMemory(MB)", max); 
		obj.put("Usecasename", "HomePage"); 
		
		try(FileWriter file = new FileWriter("myJSON.json"))
		{
			file.write(obj.toString());
			file.flush();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		
		
		System.out.println(obj);
		
	}

}
