import java.io.*;
import java.util.*;
import java.text.DecimalFormat;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
public class MainHackathonProblem2 {
	public static void main(String args[])
	{
		String ft="";
		String ft1="";
		double bd;
		double bp;
		DecimalFormat df = new DecimalFormat("#0.00"); 
		DecimalFormat df1 = new DecimalFormat("#0.000"); 
		
		try {
			FileReader fr=null;
			fr=new FileReader("E:\\java\\Battery.txt");
			BufferedReader br=new BufferedReader(fr);
			String line;
	
			while((line=br.readLine())!=null)
			{
				StringTokenizer st=new StringTokenizer(line);
				while(st.hasMoreTokens())
				{
//					if(st.nextToken().equals("activities:"))
//					{
//						//st.nextToken();
//						int str=st.nextToken().length();
//						ft = line.substring(28,line.length()).toString();
//					}
					if(st.nextToken().equals("u0a202:"))
					{
						//st.nextToken();
						ft1 = line.substring(16,21);
						System.out.print(ft1);
					}
				}
			}
			
	}catch(FileNotFoundException e)
		{
		e.printStackTrace();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		
//		bp = Double.valueOf(df.format(bp));
//		bd = Double.valueOf(df1.format(bd));
//		
//		JSONObject obj = new JSONObject();
//		
//		obj.put("Foreground_time", ft);
//		obj.put("Battery_percentage", bp);
//		obj.put("Battery_drain", bd);
//		
//		try(FileWriter file = new FileWriter("myJSON.json"))
//		{
//			file.write(obj.toString());
//			file.flush();
//		}
//		catch(IOException e)
//		{
//			e.printStackTrace();
//		}
//		
//		
//		System.out.println(obj);

}
}
